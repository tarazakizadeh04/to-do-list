import csv

class task():
    def __init__(self, name, explanation,rank):
        self.name = name
        self.explanation = explanation
        self.rank = rank

    def __str__(self):
        return f"{self.name} (Rank: {self.rank})"

def reading(file_path):
    data=[]
    try:
        with open(file_path,'r') as file:
            read =csv.reader(file)
            next(read)  
            for i in read:
                new_task = task(i[0],i[1], i[2])
                data.append(new_task)
    except FileNotFoundError:
        print("file not found.starting with empty list.")
    return data

def save_csv(file_path, result):
    with open(file_path, 'w', newline='') as filee:
        write= csv.writer(filee)
        write.writerow(['name', 'explanation', 'rank']) 
        for k in result:
            write.writerow([k.name, k.explanation, k.rank])

print("these is your to-do list: ")
result =reading(r"T:\VS_project3\To_do_list\tasl.csv")
for j in result:
    print(j)

class to_do_list():
    def __init__(self, initial_tasks=None):
        self.list_of_works=initial_tasks if initial_tasks else []

    def add_work(self, task):
        self.list_of_works.append(task)
        return 'the task added'

    def remove_work(self, task_title):
        for t in self.list_of_works:
            if t.name==task_title:
                self.list_of_works.remove(t)
                return f'the task "{task_title}" removed'
        return f'task "{task_title}" not found'

    def ranking(self):
        self.list_of_works.sort(key=lambda t: int(t.rank))

    def show_all_work(self):
        self.ranking()
        return self.list_of_works

list_of_works=to_do_list(result)

if __name__=="__main__":
    while True:
        print(
            '''
            menu:
            1. add task 
            2. remove task
            3. show the list of task
            '''
        )
        choice=input("enter just the number of one above options pls: ")
        if choice=="1":
            n = int(input('how many task do you want to add?? '))
            for i in range(n):
                name=input(f"the name of task{i+1} pls: ")
                explanation=input(f"write the explanation of task{i+1} pls: ")
                rank=input(f'the rank of task{i+1} pls: ')
                first_task=task(name, explanation, rank)
                list_of_works.add_work(first_task)
                print(f"the task{i+1} added!")
            print('list of tasks:')
            for t in list_of_works.show_all_work():
                print(t)

        elif choice=="2":
            the_task=input('what is the name of task to remove? ')
            result=list_of_works.remove_work(the_task)
            print(result)
            print('list of tasks: ')
            for i in list_of_works.show_all_work():
                print(i)

        elif choice == "3":
            print('the list of all tasks:')
            for j in list_of_works.show_all_work():
                print(j)

        solution =input("do you want to continue? (y/n). if you want to save file write 'end' pls: ")
        if solution=="n":
            print('bye')
            break
        elif solution=="end":
            second_file_path=r'T:\VS_project3\To_do_list\final_file.csv'
            save_csv(second_file_path, list_of_works.list_of_works)
            print(f'tasks saved in this path : {second_file_path} . bye')
            break
